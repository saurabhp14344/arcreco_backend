from django.apps import AppConfig


class ReconConfig(AppConfig):
    name = 'recon'
